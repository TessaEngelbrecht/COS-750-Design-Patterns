"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { QuestionCard } from "@/components/question-card"

interface PracticePageProps {
  onNext: () => void
}

const questions = [
  {
    id: 1,
    type: "fill-in-blank",
    text: "The Observer pattern defines a one-to-",
    blank: "many",
    category: "Remember",
  },
  {
    id: 2,
    type: "code-fix",
    text: "There is an issue in the code. Line 4 has a problem.",
    code: [
      "class Subject {",
      "std::vector<std::shared_ptr<Observer>> obs;",
      "public:",
      "void subscribe(std::shared_ptr<Observer> o){ obs.push_back(o); }",
      "};",
    ],
    category: "Understand",
  },
  {
    id: 3,
    type: "multiple-choice",
    text: "Best practice for Subject's list is:",
    options: [
      "A) std::unique_ptr<Observer>",
      "B) std::shared_ptr<Observer>",
      "C) Observer* raw owning",
      "D) std::weak_ptr<Observer>",
    ],
    answer: "B",
    category: "Apply",
  },
]

export function PracticePage({ onNext }: PracticePageProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answered, setAnswered] = useState<number[]>([])

  const currentQuestion = questions[currentQuestionIndex]
  const isLastQuestion = currentQuestionIndex === questions.length - 1

  const handleAnswer = (answer: any) => {
    setAnswered([...answered, currentQuestion.id])
    if (isLastQuestion) {
      onNext()
    } else {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <QuestionCard
        question={currentQuestion}
        onAnswer={handleAnswer}
        questionNumber={currentQuestionIndex + 1}
        totalQuestions={questions.length}
      />
      <div className="flex justify-between items-center mt-8">
        <Button
          variant="outline"
          onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
          disabled={currentQuestionIndex === 0}
        >
          Previous
        </Button>
        <span className="text-muted-foreground">
          Question {currentQuestionIndex + 1}/{questions.length}
        </span>
        <Button
          onClick={() => setCurrentQuestionIndex(Math.min(questions.length - 1, currentQuestionIndex + 1))}
          disabled={currentQuestionIndex === questions.length - 1}
        >
          Next
        </Button>
      </div>
    </div>
  )
}
