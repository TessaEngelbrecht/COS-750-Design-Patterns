module.exports=[72070,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_dashboard_page_actions_ae11d14d.js.map