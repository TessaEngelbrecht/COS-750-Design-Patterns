module.exports=[66285,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_practice_page_actions_dd54ec0a.js.map