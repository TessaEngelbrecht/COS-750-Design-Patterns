module.exports=[63564,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_cheat-sheet_page_actions_762aef24.js.map