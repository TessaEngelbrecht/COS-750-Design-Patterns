module.exports=[11060,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_quiz_page_actions_736e1f6d.js.map