module.exports=[49081,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_uml-builder_page_actions_03dfc8bf.js.map