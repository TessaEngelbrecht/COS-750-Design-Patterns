module.exports=[7054,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_student_results_page_actions_b5118a93.js.map