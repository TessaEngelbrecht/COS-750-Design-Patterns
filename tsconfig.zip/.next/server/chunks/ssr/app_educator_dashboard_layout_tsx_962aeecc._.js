module.exports=[81847,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b])}];

//# sourceMappingURL=app_educator_dashboard_layout_tsx_962aeecc._.js.map