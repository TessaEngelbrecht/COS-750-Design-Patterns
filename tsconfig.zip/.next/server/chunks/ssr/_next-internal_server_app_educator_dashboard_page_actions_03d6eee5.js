module.exports=[84137,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_educator_dashboard_page_actions_03d6eee5.js.map