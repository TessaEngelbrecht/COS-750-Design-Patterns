module.exports=[83541,a=>{"use strict";function b({children:a}){return a}a.s(["default",()=>b])}];

//# sourceMappingURL=app_student_layout_tsx_77c42c37._.js.map