import type React from "react"
export default function EducatorLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return children
}
